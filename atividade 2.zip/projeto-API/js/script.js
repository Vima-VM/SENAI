const api = "http://localhost:3000/produtos";

let tabela = document.getElementById("tabela");

function buscaProdutos(){
    fetch(api).then(
        response =>{
            return response.json();
        }
    ).then(
        data =>{
            data.forEach(produto => {
                tabela.innerHTML = `
                <tr>
                    <td> ${produto.id} </td>
                    <td> ${produto.nome}</td>
                    <td> ${produto.descricao}</td>
                     <td> ${produto.valor}</td>
                </tr>     
                `
            });
        }
    )

}

buscaProdutos();